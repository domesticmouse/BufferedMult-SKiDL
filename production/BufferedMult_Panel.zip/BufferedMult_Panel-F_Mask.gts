G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.1*
G04 #@! TF.CreationDate,2026-10-24T23:02:54+11:00*
G04 #@! TF.ProjectId,BufferedMult_Panel,42756666-6572-4656-944d-756c745f5061,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.1) date 2026-10-24 23:02:54*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10O,5.500000X3.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H1*
X7500000Y-3000000D03*
G04 #@! TD*
G04 #@! TO.C,H2*
X7500000Y-125500000D03*
G04 #@! TD*
M02*
